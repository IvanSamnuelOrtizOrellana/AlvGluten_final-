<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>AlvGluten | Acceso</title>
    <link rel="icon" type="image/png" href="{{ asset('images/logo_alvgluten.png') }}">

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600,800&display=swap" rel="stylesheet" />

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="font-sans text-gray-900 antialiased bg-gray-50">

<div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0">

    <div class="mb-6 text-center">
        <a href="/" wire:navigate class="flex flex-col items-center gap-2 group">
            <img src="{{ asset('images/logo_alvgluten.png') }}" alt="Logo AlvGluten" class="h-24 w-auto transition-transform group-hover:scale-105">
            
        </a>
    </div>

    <div class="w-full sm:max-w-md mt-2 px-6">
        {{ $slot }}
    </div>

</div>
</body>
</html>